// ============================================================================
// worker-login Edge Function
// ============================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import * as bcrypt from "https://deno.land/x/bcrypt@v0.4.1/mod.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_DURATION_MINUTES = 15;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return jsonResponse({ error: "missing_authorization", message: "الجهاز غير مسجل دخول" }, 401);
    }

    const { username, password } = await req.json();
    if (!username || !password) {
      return jsonResponse({ error: "invalid_input", message: "اسم المستخدم وكلمة السر مطلوبان" }, 400);
    }

    // عميل مقيد بجلسة الجهاز الحالية (يخضع لـ RLS)
    const deviceScopedClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: companyId, error: companyError } = await deviceScopedClient.rpc("get_my_company_id");

    if (companyError || !companyId) {
      return jsonResponse({ error: "unauthorized_device", message: "هذا الجهاز غير مرتبط بأي شركة" }, 403);
    }

    // عميل بصلاحية كاملة (service_role) للبحث عن العامل وتحديث البيانات
    const adminClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: worker, error: workerError } = await adminClient
      .from("workers")
      .select("id, full_name, username, password_hash, photo_url, is_active, failed_login_attempts, locked_until")
      .eq("company_id", companyId)
      .eq("username", username)
      .maybeSingle();

    if (workerError) {
      console.error("worker lookup error", workerError);
      return jsonResponse({ error: "server_error", message: "خطأ داخلي، حاول مجدداً" }, 500);
    }

    if (!worker || !worker.is_active) {
      return jsonResponse({ error: "invalid_credentials", message: "اسم المستخدم أو كلمة السر غير صحيحة" }, 401);
    }

    // فحص القفل المؤقت
    if (worker.locked_until && new Date(worker.locked_until) > new Date()) {
      const minutesLeft = Math.ceil(
        (new Date(worker.locked_until).getTime() - Date.now()) / 60000
      );
      return jsonResponse(
        {
          error: "account_locked",
          message: `الحساب مقفول مؤقتاً، حاول بعد ${minutesLeft} دقيقة`,
          locked_until: worker.locked_until,
        },
        423
      );
    }

    // استبدال compareSync بالدالة اللا تزامنية compare المتوافقة مع Deno
    const passwordMatches = await bcrypt.compare(password, worker.password_hash);

    if (!passwordMatches) {
      const newAttempts = (worker.failed_login_attempts ?? 0) + 1;
      const shouldLock = newAttempts >= MAX_FAILED_ATTEMPTS;

      await adminClient
        .from("workers")
        .update({
          failed_login_attempts: shouldLock ? 0 : newAttempts,
          locked_until: shouldLock
            ? new Date(Date.now() + LOCK_DURATION_MINUTES * 60000).toISOString()
            : null,
        })
        .eq("id", worker.id);

      if (shouldLock) {
        return jsonResponse(
          {
            error: "account_locked",
            message: `تم قفل الحساب ${LOCK_DURATION_MINUTES} دقيقة بعد محاولات فاشلة متكررة`,
          },
          423
        );
      }

      return jsonResponse(
        {
          error: "invalid_credentials",
          message: "اسم المستخدم أو كلمة السر غير صحيحة",
          attempts_remaining: MAX_FAILED_ATTEMPTS - newAttempts,
        },
        401
      );
    }

    // نجاح الدخول: تصفير العداد والتسجيل في activity_log
    await adminClient
      .from("workers")
      .update({ failed_login_attempts: 0, locked_until: null })
      .eq("id", worker.id);

    await adminClient.from("activity_log").insert({
      company_id: companyId,
      worker_id: worker.id,
      event_type: "login",
      event_label: `تسجيل دخول: ${worker.full_name}`,
    });

    return jsonResponse({
      success: true,
      worker: {
        id: worker.id,
        company_id: companyId,
        full_name: worker.full_name,
        photo_url: worker.photo_url,
      },
      session_started_at: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error("worker-login unexpected error", err);
    return jsonResponse({ error: "server_error", message: err?.message || "خطأ غير متوقع" }, 500);
  }
});